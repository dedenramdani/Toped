import React, { Component } from 'react';
import {Text,View} from 'react-native';


class Porto extends Component {
  render() {
    return (
      <View>
      <Text>Halaman porto</Text>
      </View>
    );
  }
}

export default Porto;

