import React, { Component } from 'react';
import {Text,View} from 'react-native';
import Header from '../components/Header';


class About extends Component {
  render() {
    return (
      <View>
     
      <Text>Halaman About</Text>
      </View>
    );
  }
}

export default About;

