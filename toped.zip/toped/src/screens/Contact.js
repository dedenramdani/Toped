import React, { Component } from 'react';
import {Text,View} from 'react-native';
import Header from '../components/Header';


class Contact extends Component<Props> {
  render() {
    return (
      <View>
     
      <Text>Halaman Contact</Text>
      </View>
    );
  }
}

export default Contact;

