import React, { Component } from 'react';
import Home from './src/screens/Home';
import Main from './src/screens/Main';
export default class App extends Component<Props> {
  render() {
    return (
      
      <Home />
       
    );
  }
}

